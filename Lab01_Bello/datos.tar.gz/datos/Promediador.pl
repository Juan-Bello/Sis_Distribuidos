#!/usr/bin/perl
#**************************************************************
#         		Pontificia Universidad Javeriana
#     Autor: Juan Esteban Bello Durango
#     Fecha: 15 de Agosto 2024
#     Materia: Sistemas Distribuidos
#     Tema: Taller de Evaluación de Rendimiento
#     Fichero: script automatización ejecución por lotes 
#****************************************************************/

$Path = `pwd`;
chomp($Path);

$Nombre_Ejecutable = "mmClasicaOpenMP";
@Size_Matriz = ("200","324","432","578","780","1036","1254","1410","1676","1892","2034","2592");
@Num_Hilos = (1,2,4,8,16,20);
$Repeticiones = 30;

foreach $size (@Size_Matriz){
	foreach $hilo (@Num_Hilos) {
		$file = "$Path/$Nombre_Ejecutable-".$size."-Hilos-".$hilo.".dat";
	    $p=$p+1;

    # Calcular el promedio de los tiempos almacenados en el archivo
	    my $suma = 0;
            my $conteo = 0;
            open(my $fh, '<', $file) or die "No se pudo abrir $file: $!";
	    while (my $linea = <$fh>) {
    		chomp($linea);
    		if ($linea =~ /(\d+)/) {
        		$suma += $1;
        		$conteo++;
    		}
	    }
	    close($fh);

	    # Calcular el promedio si hay datos
	    my $promedio = 0;
	    if ($conteo > 0) {
		$promedio = $suma / $conteo;
	    }

	   # Agregar el promedio al archivo
	   system("echo 'Promedio: $promedio ms' >> $file");
	}
}
# Este codigo fue reutilizado y adaptado del taller de rendimiento de sistemas operativos